<?php

return [
    'site_title' => 'Veepee',
];
