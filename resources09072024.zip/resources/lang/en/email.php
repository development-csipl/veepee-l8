<?php 

return [
    'accept_order'   => 'supplier accepted your order. Price :price INR  and number of cases are case :case',
    'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',
];