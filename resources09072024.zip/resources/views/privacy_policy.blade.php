<!DOCTYPE html>
<html>
<head>
<title>Veepee International | Privacy Policy</title>
</head>
<body>

<h1>Privacy Policy</h1>
<p>{{$site_info->privacy_policy}}</p>

</body>
</html>