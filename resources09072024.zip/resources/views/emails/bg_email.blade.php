<!DOCTYPE html>
<html>
<head>
	<title>Busy Server Down</title>
</head>
<body>
   
<center>
<h2 style="padding: 23px;background: #b3deb8a1;border-bottom: 6px green solid;">
	Busy Server Down
</h2>
</center>
  
<p>Hi, Team</p>
<p>Unfortunately Busy Server is down! Kidly contact to Busy team.</p>
  
<strong>Veepee Team :)</strong>
  
</body>
</html>