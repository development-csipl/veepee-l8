<!DOCTYPE html>
<html>
<head>
	<title>You have got a new order</title>
</head>
<body>
   
<center>
<h2 style="padding: 23px;background: #b3deb8a1;border-bottom: 6px green solid;">
	<a href="{{$link}}">You have got a new order</a>
</h2>
</center>
  
<p>Dear, {{$supplier_name}}</p>
<p>{{$buyer_name }} sent you a order please check and accept order as soon as possiable.</p>
<p><a href="{{$link}}">Order Detail</a></p>
  
<strong>Veepee Team :)</strong>
  
</body>
</html>