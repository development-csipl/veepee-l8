<!DOCTYPE html>
<html>
<head>
	<title>Order Status Changed</title>
</head>
<body>
   
<center>
<h2 style="padding: 23px;background: #b3deb8a1;border-bottom: 6px green solid;">
	Order Status Changed
</h2>
</center>
  
<p>Dear, {{$name}}</p>
<p>{{$msg}}</p>
  
<strong>Veepee Team :)</strong>
  
</body>
</html>