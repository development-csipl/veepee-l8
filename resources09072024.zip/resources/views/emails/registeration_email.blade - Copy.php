<!DOCTYPE html>
<html>
<head>
	<title>Veepee</title>
</head>
<body>
	<h1 style="text-align: center;">Veepee</h1>
	<p>Congratulation! Your veepee account has been created successfully. Your credentials are :  </p>
	<p><b>Username : </b> {{$user_name}}</p> <br>
	<p><b>Password : </b> {{$password}}</p> <br>

</body>
</html>