<!DOCTYPE html>
<html>
<head>
	<title>Veepee</title>
</head>
<body>
	<h1 style="text-align: center;">Veepee: Reset Password</h1>
	
	<p>Dear {{$user_name}}, <br>
	We have sent a password reset link.Please click on below link to reset your password. </p>
	<p><b>Link : </b> <a href="{{$link}}">{{$link}} </a></p>

</body>
</html>