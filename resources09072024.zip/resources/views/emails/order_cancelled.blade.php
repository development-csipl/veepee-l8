<!DOCTYPE html>
<html>
<head>
	<title>Order Cancelled </title>
</head>
<body>
<p>Dear, {{$BName}}</p>

<center><h2 style="padding: 23px;background: #b3deb8a1;border-bottom: 6px green solid;"> Order Cancelled </h2></center>

<p>{{$Msg}}</p>

<p>Order Date: {{ $ODate }} </p>
  
<strong>Veepee Team :)</strong>
  
</body>
</html>