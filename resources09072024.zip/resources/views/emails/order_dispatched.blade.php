<!DOCTYPE html>
<html>
<head>
	<title>Order Dispatched</title>
</head>
<body>
   
<center>
<h2 style="padding: 23px;background: #b3deb8a1;border-bottom: 6px green solid;">
	Order ({{$order_id}}) Dispatched 
</h2>
</center>
  
<p>Dear,</p>
<p>{!! $msg !!}</p>
  
<strong>Veepee Team :)</strong>
  
</body>
</html>