<!DOCTYPE html>
<html>
<head>
	<title>Dispatch order immediately</title>
</head>
<body>
   
<center>
<h2 style="padding: 23px;background: #b3deb8a1;border-bottom: 6px green solid;">
	<a href="{{$link}}">Dispatch order immediately after {{$expirydate}} it will cancelled autometically.</a>
</h2>
</center>
  
<p>Hi, {{$supplier_name}}</p>
<p>This Order will be expired on {{$expirydate}} . Please dispatch it soon. Otherwise it will cancelled autometically.</p>
  
<strong>Veepee Team :)</strong>
  
</body>
</html>