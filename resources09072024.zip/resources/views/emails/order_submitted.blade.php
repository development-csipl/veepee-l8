<!DOCTYPE html>
<html>
<head>
	<title>You have got a new order</title>
</head>
<body>
   
<center>
<h2 style="padding: 23px;background: #b3deb8a1;border-bottom: 6px green solid;">
	Order request has been sent successfully
</h2>
</center>
  
<p>Dear, {{$buyer_name }}</p>
<p>We have sent your order request to the supplier and waiting for acceptence.</p>
  
<strong>Veepee Team :)</strong>
  
</body>
</html>